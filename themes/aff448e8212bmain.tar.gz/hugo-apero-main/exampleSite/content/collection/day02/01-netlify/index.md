---
title: "Netlify"
weight: 1
subtitle: "Using Netlify to deploy."
excerpt: "Grid is the very first CSS module created specifically to solve the layout problems we’ve all been hacking our way around for as long as we’ve been making websites."
date: 2021-01-02
draft: false
---


So far, we've been leveraging GitHub Pages for publishing. This works great, but for blogdown we'll start using Netlify. Let's start *RIGHT NOW* with a site we've already built and published.

## Pre-requisites

Pick either your postcards site, or your distill site from day 01. Refresh your memory- which repository was it again?