---
title: "A GitHub profile"
weight: 1
subtitle: "Put your best foot forward, first."
excerpt: "You can share information about yourself with the community on GitHub by creating a profile README. GitHub shows your profile README at the top of your profile page."
date: 2021-01-01
draft: false
links:
- icon: door-open
  icon_pack: fas
  name: website
  url: https://bakeoff.netlify.com/
- icon: github
  icon_pack: fab
  name: code
  url: https://github.com/apreshill/bakeoff
---

## Profile

https://docs.github.com/en/github/setting-up-and-managing-your-github-profile/personalizing-your-profile

## Pin projects to profile

https://docs.github.com/en/github/setting-up-and-managing-your-github-profile/pinning-items-to-your-profile

## Profile README

This is new! Let's do it:

https://docs.github.com/en/github/setting-up-and-managing-your-github-profile/managing-your-profile-readme
