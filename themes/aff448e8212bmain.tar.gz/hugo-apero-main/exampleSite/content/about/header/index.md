---
## Configure header of page
text_align_right: false
show_title_as_headline: false
headline: |
  Hi, my name is Hugo Apéro. Nice to meet you.
---

<!-- this is a subheadline -->
I'm a Hugo theme you'll want to hang out with. :fr: 

The page you are reading is based on a markdown file- look in `content/about/` to edit. There, look inside the `header`, `main`, and `sidebar` folders to get started building your own "about" page.