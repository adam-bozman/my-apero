---
title: "A campfire"
subtitle: "Testing"
excerpt: "Here is a talk I gave on making awesome personal websites using Hugo, blogdown, GitHub, and Netlify."
date: 2021-01-12
date_end: "2021-01-13"
featured: true
show_post_time: false
event: "rstudio::global(2021)"
event_url: https://global.rstudio.com
author: "Alison Hill"
location: "Sydney, Australia"
draft: false
# layout options: single, single-sidebar
layout: single
categories:
- workshop
links:
- icon: door-open
  icon_pack: fas
  name: website
  url: https://bakeoff.netlify.com/
- icon: github
  icon_pack: fab
  name: code
  url: https://github.com/apreshill/bakeoff
---

I'm really excited to give this talk! Stay tuned for video and slides.
